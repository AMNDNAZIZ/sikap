-- TABEL: jenis_bayar
CREATE TABLE `jenis_bayar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos_bayar_id` int(11) NOT NULL,
  `tahun_ajaran_id` int(11) NOT NULL,
  `nama_jenis_bayar` varchar(100) NOT NULL,
  `tipe` enum('bulanan','bebas') NOT NULL,
  `tarif_default` int(11) DEFAULT NULL,
  `wajib` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jenis_bayar` (`id`, `pos_bayar_id`, `tahun_ajaran_id`, `nama_jenis_bayar`, `tipe`, `tarif_default`, `wajib`, `created_at`, `updated_at`) VALUES ('1', '1', '1', 'SPP 2024/2025', 'bulanan', '240000', '1', '2025-05-15 10:43:22', '2025-05-15 10:43:22');
INSERT INTO `jenis_bayar` (`id`, `pos_bayar_id`, `tahun_ajaran_id`, `nama_jenis_bayar`, `tipe`, `tarif_default`, `wajib`, `created_at`, `updated_at`) VALUES ('2', '2', '1', 'PPDB 2024/2025', 'bebas', '1500000', '1', '2025-05-15 10:43:51', '2025-05-15 10:43:51');
INSERT INTO `jenis_bayar` (`id`, `pos_bayar_id`, `tahun_ajaran_id`, `nama_jenis_bayar`, `tipe`, `tarif_default`, `wajib`, `created_at`, `updated_at`) VALUES ('3', '1', '2', 'SPP 2024/2025', 'bulanan', '220000', '1', '2025-05-15 11:47:33', '2025-05-15 11:47:33');
INSERT INTO `jenis_bayar` (`id`, `pos_bayar_id`, `tahun_ajaran_id`, `nama_jenis_bayar`, `tipe`, `tarif_default`, `wajib`, `created_at`, `updated_at`) VALUES ('4', '2', '2', 'PPDB 2024/2025', 'bebas', '1500000', '1', '2025-05-15 11:47:55', '2025-05-15 11:47:55');
INSERT INTO `jenis_bayar` (`id`, `pos_bayar_id`, `tahun_ajaran_id`, `nama_jenis_bayar`, `tipe`, `tarif_default`, `wajib`, `created_at`, `updated_at`) VALUES ('5', '5', '1', 'Akhir Tahun 2024/2025', 'bebas', NULL, '1', '2025-05-20 08:08:13', '2025-05-20 08:08:13');
INSERT INTO `jenis_bayar` (`id`, `pos_bayar_id`, `tahun_ajaran_id`, `nama_jenis_bayar`, `tipe`, `tarif_default`, `wajib`, `created_at`, `updated_at`) VALUES ('6', '3', '1', 'Kegiatan 2024/2025', 'bebas', NULL, '1', '2025-05-20 11:29:48', '2025-05-20 11:29:48');

-- TABEL: kasbon
CREATE TABLE `kasbon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `dibayar` int(11) NOT NULL DEFAULT 0,
  `status` enum('belum','lunas') NOT NULL DEFAULT 'belum',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `kasbon` (`id`, `tanggal`, `nama`, `jumlah`, `dibayar`, `status`, `created_at`, `updated_at`) VALUES ('1', '2025-05-22', 'Arjuna', '2000000', '500000', 'belum', '2025-05-22 04:15:29', '2025-05-22 04:19:18');
INSERT INTO `kasbon` (`id`, `tanggal`, `nama`, `jumlah`, `dibayar`, `status`, `created_at`, `updated_at`) VALUES ('3', '2025-05-26', 'Bima', '1500000', '500000', 'belum', '2025-05-26 13:45:47', '2025-05-26 13:46:59');
INSERT INTO `kasbon` (`id`, `tanggal`, `nama`, `jumlah`, `dibayar`, `status`, `created_at`, `updated_at`) VALUES ('4', '2025-06-09', 'Bima', '1000000', '0', 'belum', '2025-06-09 12:50:58', '2025-06-09 12:50:58');

-- TABEL: kasbon_bayar
CREATE TABLE `kasbon_bayar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kasbon_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` int(11) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `kasbon_bayar` (`id`, `kasbon_id`, `tanggal`, `jumlah`, `keterangan`, `created_at`, `updated_at`) VALUES ('1', '1', '2025-05-22', '500000', '', '2025-05-22 04:19:18', '2025-05-22 04:19:18');
INSERT INTO `kasbon_bayar` (`id`, `kasbon_id`, `tanggal`, `jumlah`, `keterangan`, `created_at`, `updated_at`) VALUES ('3', '3', '2025-05-26', '500000', 'Cicilan Ke 1', '2025-05-26 13:46:59', '2025-05-26 13:46:59');

-- TABEL: kasbon_cicilan
CREATE TABLE `kasbon_cicilan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kasbon_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(12,2) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABEL: kasbon_guru
CREATE TABLE `kasbon_guru` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guru_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` decimal(12,2) NOT NULL,
  `terbayar` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('lunas','belum') NOT NULL DEFAULT 'belum',
  `keterangan` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABEL: kelas
CREATE TABLE `kelas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kelas` varchar(100) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `kelas` (`id`, `nama_kelas`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('1', '7A', 'Kelas 7A', '1', '2025-05-16 03:53:36', '2025-05-16 03:53:36');
INSERT INTO `kelas` (`id`, `nama_kelas`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('2', '7B', 'Kelas 7B', '1', '2025-05-16 03:53:44', '2025-05-16 03:53:44');
INSERT INTO `kelas` (`id`, `nama_kelas`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('3', '7C', 'Kelas 7C', '1', '2025-05-16 03:53:53', '2025-05-16 03:53:53');
INSERT INTO `kelas` (`id`, `nama_kelas`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('4', '8A', 'Kelas 8A', '1', '2025-05-16 03:54:02', '2025-05-16 03:54:02');
INSERT INTO `kelas` (`id`, `nama_kelas`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('5', '8B', 'Kelas 8B', '1', '2025-05-16 03:54:11', '2025-05-16 03:54:11');
INSERT INTO `kelas` (`id`, `nama_kelas`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('6', '8C', 'Kelas 8C', '1', '2025-05-16 03:54:30', '2025-05-16 03:54:30');

-- TABEL: kelas_siswa
CREATE TABLE `kelas_siswa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siswa_id` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `tahun_ajaran_id` int(11) NOT NULL,
  `status` enum('aktif','lulus','pindah','do') NOT NULL DEFAULT 'aktif',
  `tanggal_masuk` date DEFAULT NULL,
  `tanggal_keluar` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;

INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('1', '1', '1', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:55:59', '2025-05-16 03:55:59');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('2', '2', '1', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:55:59', '2025-05-16 03:55:59');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('3', '3', '1', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:55:59', '2025-05-16 03:55:59');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('4', '4', '1', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:55:59', '2025-05-16 03:55:59');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('5', '5', '1', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:55:59', '2025-05-16 03:55:59');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('6', '6', '1', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:55:59', '2025-05-16 03:55:59');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('7', '7', '1', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:55:59', '2025-05-16 03:55:59');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('8', '8', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:13', '2025-05-16 03:56:13');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('9', '9', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:13', '2025-05-16 03:56:13');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('10', '10', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:13', '2025-05-16 03:56:13');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('11', '11', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:13', '2025-05-16 03:56:13');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('12', '12', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:13', '2025-05-16 03:56:13');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('13', '13', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:13', '2025-05-16 03:56:13');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('14', '14', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:13', '2025-05-16 03:56:13');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('15', '15', '3', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:23', '2025-05-16 03:56:23');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('16', '16', '3', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:23', '2025-05-16 03:56:23');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('17', '17', '3', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:23', '2025-05-16 03:56:23');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('18', '18', '3', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:23', '2025-05-16 03:56:23');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('19', '19', '3', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:23', '2025-05-16 03:56:23');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('20', '20', '5', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:55', '2025-05-16 03:56:55');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('21', '21', '5', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:55', '2025-05-16 03:56:55');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('22', '22', '5', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:55', '2025-05-16 03:56:55');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('23', '23', '5', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:55', '2025-05-16 03:56:55');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('24', '24', '5', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:55', '2025-05-16 03:56:55');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('25', '25', '5', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:56:55', '2025-05-16 03:56:55');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('26', '26', '4', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:57:39', '2025-05-16 03:57:39');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('27', '27', '4', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:57:39', '2025-05-16 03:57:39');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('28', '28', '4', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:57:39', '2025-05-16 03:57:39');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('29', '29', '4', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:57:39', '2025-05-16 03:57:39');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('30', '30', '4', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:57:39', '2025-05-16 03:57:39');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('31', '31', '4', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:57:39', '2025-05-16 03:57:39');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('32', '32', '4', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:57:39', '2025-05-16 03:57:39');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('33', '33', '4', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:57:39', '2025-05-16 03:57:39');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('34', '34', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('35', '35', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('36', '36', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('37', '37', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('38', '38', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('39', '39', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('40', '40', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('41', '41', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('42', '42', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('43', '43', '6', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:03', '2025-05-16 03:58:03');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('44', '44', '1', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:12', '2025-05-16 03:58:12');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('45', '45', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:12', '2025-06-08 13:10:46');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('46', '46', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:18', '2025-05-16 03:58:18');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('47', '47', '2', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:18', '2025-05-16 03:58:18');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('48', '48', '3', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:25', '2025-05-16 03:58:25');
INSERT INTO `kelas_siswa` (`id`, `siswa_id`, `kelas_id`, `tahun_ajaran_id`, `status`, `tanggal_masuk`, `tanggal_keluar`, `created_at`, `updated_at`) VALUES ('49', '49', '3', '1', 'aktif', '2025-05-16', NULL, '2025-05-16 03:58:25', '2025-05-16 03:58:25');

-- TABEL: migrations
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4;

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('28', '2025-05-10-163754', 'App\\Database\\Migrations\\CreatePosBayar', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('29', '2025-05-10-163810', 'App\\Database\\Migrations\\CreateTahunAjaran', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('30', '2025-05-10-163841', 'App\\Database\\Migrations\\CreateJenisBayar', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('31', '2025-05-10-163853', 'App\\Database\\Migrations\\CreateUsers', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('32', '2025-05-10-163907', 'App\\Database\\Migrations\\CreateUserPosBayar', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('33', '2025-05-15-115549', 'App\\Database\\Migrations\\CreateKelas', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('34', '2025-05-15-122320', 'App\\Database\\Migrations\\CreateSiswa', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('35', '2025-05-15-155841', 'App\\Database\\Migrations\\CreateKelasSiswa', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('36', '2025-05-15-204247', 'App\\Database\\Migrations\\CreateTagihanSiswa', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('37', '2025-05-16-000019', 'App\\Database\\Migrations\\CreatePembayaran', 'default', 'App', '1747367508', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('38', '2025-05-16-061129', 'App\\Database\\Migrations\\AddCaraBayarToTagihanSiswa', 'default', 'App', '1747375925', '2');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('39', '2025-05-16-230309', 'App\\Database\\Migrations\\AddAngsuranKeToPembayaran', 'default', 'App', '1747436623', '3');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('40', '2025-05-20-075924', 'App\\Database\\Migrations\\UbahTarifDefaultNullable', 'default', 'App', '1747728013', '4');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('41', '2025-05-20-095732', 'App\\Database\\Migrations\\CreateSetting', 'default', 'App', '1747735274', '5');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('42', '2025-05-21-231105', 'App\\Database\\Migrations\\CreatePengumuman', 'default', 'App', '1747869134', '6');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('43', '2025-05-22-000045', 'App\\Database\\Migrations\\KasbonGuru', 'default', 'App', '1747872313', '7');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('44', '2025-05-22-000057', 'App\\Database\\Migrations\\KasbonCicilan', 'default', 'App', '1747872313', '7');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('45', '2025-05-22-040952', 'App\\Database\\Migrations\\CreateKasbon', 'default', 'App', '1747887297', '8');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('46', '2025-05-22-041027', 'App\\Database\\Migrations\\CreateKasbonBayar', 'default', 'App', '1747887297', '8');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('47', '2025-05-26-153642', 'App\\Database\\Migrations\\CreateTransaksiPos', 'default', 'App', '1748275848', '9');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('48', '2025-05-26-154527', 'App\\Database\\Migrations\\CreatePosBayarSaldo', 'default', 'App', '1748275848', '9');

-- TABEL: pembayaran
CREATE TABLE `pembayaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tagihan_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah_bayar` decimal(12,2) NOT NULL,
  `angsuran_ke` int(11) DEFAULT NULL,
  `cara_bayar` varchar(20) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('39', '8', '2025-05-20', '240000.00', NULL, NULL, NULL, '2025-05-20 04:49:38', '2025-05-20 04:49:38');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('41', '9', '2025-05-20', '240000.00', NULL, NULL, NULL, '2025-05-20 04:50:00', '2025-05-20 04:50:00');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('43', '10', '2025-05-20', '240000.00', NULL, NULL, NULL, '2025-05-20 04:51:21', '2025-05-20 04:51:21');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('45', '11', '2025-05-20', '240000.00', NULL, NULL, NULL, '2025-05-20 04:52:18', '2025-05-20 04:52:18');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('104', '217', '2025-05-21', '500000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-05-21 11:51:38', '2025-05-21 11:51:38');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('106', '235', '2025-05-21', '500000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-05-21 12:02:29', '2025-05-21 12:02:29');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('109', '235', '2025-05-21', '500000.00', '2', 'Transfer', 'Angsuran ke-2', '2025-05-21 12:13:42', '2025-05-21 12:13:42');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('110', '235', '2025-05-21', '200000.00', '3', 'Tunai', 'Angsuran ke-3', '2025-05-21 12:34:07', '2025-05-21 12:34:07');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('111', '235', '2025-05-21', '200000.00', '4', 'Tunai', 'Angsuran ke-4', '2025-05-21 12:36:21', '2025-05-21 12:36:21');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('139', '217', '2025-05-26', '500000.00', '2', 'BPMS', 'Angsuran ke-2', '2025-05-26 13:41:40', '2025-05-26 13:41:40');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('141', '7', '2025-05-27', '240000.00', NULL, 'Tunai', NULL, '2025-05-27 09:00:34', '2025-05-27 09:00:34');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('142', '8', '2025-05-27', '240000.00', NULL, 'Tunai', NULL, '2025-05-27 09:00:38', '2025-05-27 09:00:38');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('143', '9', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 09:01:55', '2025-06-07 09:01:55');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('145', '19', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:28', '2025-06-07 14:54:28');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('146', '20', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:30', '2025-06-07 14:54:30');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('147', '21', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:31', '2025-06-07 14:54:31');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('148', '22', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:32', '2025-06-07 14:54:32');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('149', '23', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:33', '2025-06-07 14:54:33');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('150', '24', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:34', '2025-06-07 14:54:34');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('151', '13', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:35', '2025-06-07 14:54:35');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('152', '14', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:37', '2025-06-07 14:54:37');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('153', '15', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:38', '2025-06-07 14:54:38');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('154', '16', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:39', '2025-06-07 14:54:39');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('155', '17', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:40', '2025-06-07 14:54:40');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('156', '18', '2025-06-07', '240000.00', NULL, 'Tunai', NULL, '2025-06-07 14:54:41', '2025-06-07 14:54:41');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('157', '235', '2025-06-08', '600000.00', '5', 'Tunai', 'Angsuran ke-5', '2025-06-08 05:25:23', '2025-06-08 05:25:23');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('159', '218', '2025-06-10', '1000000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-06-10 05:01:31', '2025-06-10 05:01:31');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('160', '218', '2025-06-10', '500000.00', '2', 'Transfer', 'Angsuran ke-2', '2025-06-10 05:16:17', '2025-06-10 05:16:17');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('167', '219', '2025-06-10', '500000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-06-10 06:21:14', '2025-06-10 06:21:14');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('168', '237', '2025-06-10', '2000000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-06-10 06:21:28', '2025-06-10 06:21:28');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('169', '31', '2025-06-10', '240000.00', NULL, 'Tunai', NULL, '2025-06-10 06:30:39', '2025-06-10 06:30:39');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('170', '32', '2025-06-10', '240000.00', NULL, 'Tunai', NULL, '2025-06-10 06:30:40', '2025-06-10 06:30:40');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('171', '33', '2025-06-10', '240000.00', NULL, 'Transfer', NULL, '2025-06-10 06:30:44', '2025-06-10 06:30:44');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('172', '34', '2025-06-10', '240000.00', NULL, 'Transfer', NULL, '2025-06-10 06:30:48', '2025-06-10 06:30:48');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('173', '220', '2025-06-10', '1000000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-06-10 06:49:39', '2025-06-10 06:49:39');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('174', '238', '2025-06-10', '500000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-06-10 06:49:53', '2025-06-10 06:49:53');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('175', '222', '2025-06-10', '1500000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-06-10 06:54:36', '2025-06-10 06:54:36');
INSERT INTO `pembayaran` (`id`, `tagihan_id`, `tanggal`, `jumlah_bayar`, `angsuran_ke`, `cara_bayar`, `keterangan`, `created_at`, `updated_at`) VALUES ('176', '226', '2025-06-10', '1500000.00', '1', 'Tunai', 'Angsuran ke-1', '2025-06-10 07:11:25', '2025-06-10 07:11:25');

-- TABEL: pengumuman
CREATE TABLE `pengumuman` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pengumuman` (`id`, `judul`, `isi`, `aktif`, `created_at`, `updated_at`) VALUES ('1', 'Pengumuman', 'Lakukan Pembayaran SPP paling lambat tanggal 10 setiap bulannya.\r\nMintalah selalu tanda bukti pembayaran setiap melakukan pembayaran apapun di SMP Islam Tambora.', '1', '2025-05-21 23:21:44', '2025-06-10 11:00:45');

-- TABEL: pos_bayar
CREATE TABLE `pos_bayar` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nama_pos` varchar(100) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `pos_bayar` (`id`, `nama_pos`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('1', 'SPP', 'Sumbangan Pembinaan Pendidikan', '1', '2025-05-15 06:34:02', NULL);
INSERT INTO `pos_bayar` (`id`, `nama_pos`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('2', 'PPDB', 'Penerimaan Peserta Didik Baru', '1', '2025-05-15 06:34:02', NULL);
INSERT INTO `pos_bayar` (`id`, `nama_pos`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('3', 'Kegiatan Tahunan', 'Outbond, Class Meeting, dll', '1', '2025-05-15 06:34:02', NULL);
INSERT INTO `pos_bayar` (`id`, `nama_pos`, `keterangan`, `aktif`, `created_at`, `updated_at`) VALUES ('5', 'Akhir Tahun', 'Pembayaran Akhir Tahun', '1', '2025-05-20 07:40:34', '2025-05-20 07:40:34');

-- TABEL: pos_bayar_saldo
CREATE TABLE `pos_bayar_saldo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pos_bayar_id` int(10) unsigned NOT NULL,
  `masuk` int(11) NOT NULL DEFAULT 0,
  `keluar` int(11) NOT NULL DEFAULT 0,
  `saldo` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pos_bayar_id` (`pos_bayar_id`),
  CONSTRAINT `pos_bayar_saldo_pos_bayar_id_foreign` FOREIGN KEY (`pos_bayar_id`) REFERENCES `pos_bayar` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABEL: setting
CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_aplikasi` varchar(255) NOT NULL,
  `nama_sekolah` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `kepala_sekolah` varchar(100) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `setting` (`id`, `nama_aplikasi`, `nama_sekolah`, `alamat`, `no_hp`, `kepala_sekolah`, `logo`, `website`, `email`, `created_at`, `updated_at`) VALUES ('1', 'INFORMASI PEMBAYARAN', 'SMP Islam Tambora ', 'Jl. Tambora Masjid No.11 Tambora', '081234556574', 'Solehudin, S.Pd.,MM', 'uploads/logo/1747735569_b6f8718770b5fc3a9c7d.png', 'https://smpistora.sch.id', 'smpistora2@gmail.com', '2025-05-20 10:06:09', '2025-06-10 11:14:13');

-- TABEL: siswa
CREATE TABLE `siswa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nis` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nis` (`nis`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;

INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('1', '1122', 'ABIDZAR AL GHIFARY', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('2', '1123', 'ABIDZAR ALFI HIDAYAT', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('3', '1124', 'ABIDZAR ATTAMIMI', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('4', '1125', 'ABIDZAR GUSTI KURNIAWAN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('5', '1126', 'ABIZAR SARFARZ FAIZAN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('6', '1127', 'ADE AZZAHRA DERMAWAN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('7', '1128', 'ADINDA KHAIRUNNISA RAMADHAN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('8', '1129', 'ADIYASAH WIDRA SAPUTRA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('9', '1130', 'ADRIAN AKBAR PANGESTU', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('10', '1131', 'ADZKHAN FIRMANSYAH', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('11', '1132', 'AFFAN ALGAZALY', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('12', '1133', 'AFNI NURUL FADILLAH ADZHA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('13', '1134', 'AGRECIA GABRIELA SARAGIH', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('14', '1135', 'AHMAD AKBARUDIN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('15', '1136', 'AHMAD MUHAEMIN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('16', '1137', 'AINNUN GHOZALLI', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('17', '1138', 'AINUN PERMATASARI', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('18', '1139', 'AIRA NABILA PUTRI', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('19', '1140', 'AIRLANGGA KUSUMA WARDHANA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('20', '1141', 'AISYAH AYUDIA NARA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('21', '1142', 'AISYAH INARA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('22', '1143', 'AISYAH RANAZ', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('23', '1144', 'AKILAH SYARIAH', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('24', '1145', 'AKMAL FADHIL PRATAMA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('25', '1146', 'AL WALID SYAHRIL HAJJ', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('26', '1147', 'ALBY ABYAN KUSUMA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('27', '1148', 'ALFAN SYAHRIL', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('28', '1149', 'ALFI INAYA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('29', '1150', 'ALFIANDRA MALIQ DINATA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('30', '1151', 'ALIANDIKA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('31', '1152', 'ALIANDO HAIKAL NUGROHO', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('32', '1153', 'ALIF RAINANDES', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('33', '1154', 'ALIFA NAUFALIN FITRIA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('34', '1155', 'ALIFAH APRIANI', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('35', '1156', 'ALISA NUGRAHA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('36', '1157', 'ALIYA SIFA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('37', '1158', 'ALLEA PUTRI SALSABILLA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('38', '1159', 'ALLISHA SAFA HAURA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('39', '1160', 'ALMER FIGO JUNUKA ARIFIN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('40', '1161', 'ALSYAH JUANNATHAN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('41', '1162', 'ALVARO IBRAHIMOVIC SUSANTO', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('42', '1163', 'ALVARO ISKANDAR', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('43', '1164', 'ALVIN WIJAYA TAN', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('44', '1165', 'ALYA CHAIRUNNISA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('45', '1166', 'ALYA PUTRI PRATAMA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('46', '1167', 'ALYSA KHAHIRAH PUTRI', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('47', '1168', 'ALYSA LUVIARA', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('48', '1169', 'AMELIA NOVIYANTI', '2025-05-16 03:55:16', '2025-05-16 03:55:16');
INSERT INTO `siswa` (`id`, `nis`, `nama`, `created_at`, `updated_at`) VALUES ('49', '1170', 'ANA ELIYANA PUTRI', '2025-05-16 03:55:16', '2025-05-16 03:55:16');

-- TABEL: tagihan_siswa
CREATE TABLE `tagihan_siswa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siswa_id` int(11) NOT NULL,
  `jenis_bayar_id` int(11) NOT NULL,
  `tahun_ajaran_id` int(11) NOT NULL,
  `tipe` enum('bulanan','bebas') NOT NULL,
  `bulan` tinyint(4) DEFAULT NULL,
  `jumlah` decimal(10,2) NOT NULL,
  `terbayar` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('belum','lunas') NOT NULL DEFAULT 'belum',
  `cara_bayar` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=337 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('1', '1', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-26 10:07:48');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('2', '1', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-26 10:07:45');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('3', '1', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 14:25:21');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('4', '1', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 14:25:25');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('5', '1', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 14:25:28');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('6', '1', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 14:25:32');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('7', '1', '1', '1', 'bulanan', '1', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-05-27 09:00:34');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('8', '1', '1', '1', 'bulanan', '2', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-05-27 09:00:38');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('9', '1', '1', '1', 'bulanan', '3', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 09:01:55');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('10', '1', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-06-10 06:14:06');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('11', '1', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-06-10 06:13:54');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('12', '1', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-06-10 06:13:28');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('13', '2', '1', '1', 'bulanan', '7', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:35');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('14', '2', '1', '1', 'bulanan', '8', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:37');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('15', '2', '1', '1', 'bulanan', '9', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:38');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('16', '2', '1', '1', 'bulanan', '10', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:39');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('17', '2', '1', '1', 'bulanan', '11', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:40');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('18', '2', '1', '1', 'bulanan', '12', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:41');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('19', '2', '1', '1', 'bulanan', '1', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:28');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('20', '2', '1', '1', 'bulanan', '2', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:30');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('21', '2', '1', '1', 'bulanan', '3', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:31');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('22', '2', '1', '1', 'bulanan', '4', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:32');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('23', '2', '1', '1', 'bulanan', '5', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:33');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('24', '2', '1', '1', 'bulanan', '6', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-07 14:54:34');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('25', '3', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('26', '3', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('27', '3', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('28', '3', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('29', '3', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('30', '3', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('31', '3', '1', '1', 'bulanan', '1', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-10 06:30:39');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('32', '3', '1', '1', 'bulanan', '2', '240000.00', '240000.00', 'lunas', 'Tunai', '2025-05-16 03:59:01', '2025-06-10 06:30:40');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('33', '3', '1', '1', 'bulanan', '3', '240000.00', '240000.00', 'lunas', 'Transfer', '2025-05-16 03:59:01', '2025-06-10 06:30:44');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('34', '3', '1', '1', 'bulanan', '4', '240000.00', '240000.00', 'lunas', 'Transfer', '2025-05-16 03:59:01', '2025-06-10 06:30:48');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('35', '3', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('36', '3', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('37', '4', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('38', '4', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('39', '4', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('40', '4', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('41', '4', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('42', '4', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('43', '4', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('44', '4', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('45', '4', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('46', '4', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('47', '4', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('48', '4', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('49', '5', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('50', '5', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('51', '5', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('52', '5', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('53', '5', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('54', '5', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('55', '5', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('56', '5', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('57', '5', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('58', '5', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('59', '5', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('60', '5', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('61', '6', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('62', '6', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('63', '6', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('64', '6', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('65', '6', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('66', '6', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('67', '6', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('68', '6', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('69', '6', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('70', '6', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('71', '6', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('72', '6', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('73', '7', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('74', '7', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('75', '7', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('76', '7', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('77', '7', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('78', '7', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('79', '7', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('80', '7', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('81', '7', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('82', '7', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('83', '7', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('84', '7', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('85', '44', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('86', '44', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('87', '44', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('88', '44', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('89', '44', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('90', '44', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('91', '44', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('92', '44', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('93', '44', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('94', '44', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('95', '44', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('96', '44', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('97', '45', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('98', '45', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('99', '45', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('100', '45', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('101', '45', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('102', '45', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('103', '45', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('104', '45', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('105', '45', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('106', '45', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('107', '45', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('108', '45', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:01', '2025-05-16 03:59:01');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('109', '8', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('110', '8', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('111', '8', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('112', '8', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('113', '8', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('114', '8', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('115', '8', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('116', '8', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('117', '8', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('118', '8', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('119', '8', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('120', '8', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('121', '9', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('122', '9', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('123', '9', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('124', '9', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('125', '9', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('126', '9', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('127', '9', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('128', '9', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('129', '9', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('130', '9', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('131', '9', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('132', '9', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('133', '10', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('134', '10', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('135', '10', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('136', '10', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('137', '10', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('138', '10', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('139', '10', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('140', '10', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('141', '10', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('142', '10', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('143', '10', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('144', '10', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('145', '11', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('146', '11', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('147', '11', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('148', '11', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('149', '11', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('150', '11', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('151', '11', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('152', '11', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('153', '11', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('154', '11', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('155', '11', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('156', '11', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('157', '12', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('158', '12', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('159', '12', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('160', '12', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('161', '12', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('162', '12', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('163', '12', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('164', '12', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('165', '12', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('166', '12', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('167', '12', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('168', '12', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('169', '13', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('170', '13', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('171', '13', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('172', '13', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('173', '13', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('174', '13', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('175', '13', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('176', '13', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('177', '13', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('178', '13', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('179', '13', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('180', '13', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('181', '14', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('182', '14', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('183', '14', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('184', '14', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('185', '14', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('186', '14', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('187', '14', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('188', '14', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('189', '14', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('190', '14', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('191', '14', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('192', '14', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('193', '46', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('194', '46', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('195', '46', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('196', '46', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('197', '46', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('198', '46', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('199', '46', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('200', '46', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('201', '46', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('202', '46', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('203', '46', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('204', '46', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('205', '47', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('206', '47', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('207', '47', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('208', '47', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('209', '47', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('210', '47', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('211', '47', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('212', '47', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('213', '47', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('214', '47', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('215', '47', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('216', '47', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:16', '2025-06-07 11:13:24');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('217', '1', '2', '1', 'bebas', NULL, '1500000.00', '1000000.00', 'belum', 'BPMS', '2025-05-16 03:59:32', '2025-06-10 06:14:27');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('218', '2', '2', '1', 'bebas', NULL, '1500000.00', '1500000.00', 'lunas', 'Transfer', '2025-05-16 03:59:32', '2025-06-10 05:16:17');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('219', '3', '2', '1', 'bebas', NULL, '1500000.00', '500000.00', 'belum', 'Tunai', '2025-05-16 03:59:32', '2025-06-10 06:21:14');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('220', '4', '2', '1', 'bebas', NULL, '1500000.00', '1000000.00', 'belum', 'Tunai', '2025-05-16 03:59:32', '2025-06-10 06:49:39');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('221', '5', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:32', '2025-05-16 03:59:32');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('222', '6', '2', '1', 'bebas', NULL, '1500000.00', '1500000.00', 'lunas', 'Tunai', '2025-05-16 03:59:32', '2025-06-10 06:54:36');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('223', '7', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:32', '2025-05-16 03:59:32');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('224', '44', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:32', '2025-05-16 03:59:32');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('225', '45', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:32', '2025-05-16 03:59:32');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('226', '8', '2', '1', 'bebas', NULL, '1500000.00', '1500000.00', 'lunas', 'Tunai', '2025-05-16 03:59:50', '2025-06-10 07:11:25');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('227', '9', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:50', '2025-05-16 03:59:50');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('228', '10', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:50', '2025-05-16 03:59:50');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('229', '11', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:50', '2025-05-16 03:59:50');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('230', '12', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:50', '2025-05-16 03:59:50');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('231', '13', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:50', '2025-05-16 03:59:50');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('232', '14', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:50', '2025-05-16 03:59:50');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('233', '46', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:50', '2025-05-16 03:59:50');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('234', '47', '2', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-05-16 03:59:50', '2025-05-16 03:59:50');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('235', '1', '6', '1', 'bebas', NULL, '2000000.00', '2000000.00', 'lunas', 'Tunai', '2025-05-20 12:11:07', '2025-06-08 05:25:23');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('236', '2', '6', '1', 'bebas', NULL, '2000000.00', '0.00', 'belum', NULL, '2025-05-20 12:11:07', '2025-05-20 12:11:07');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('237', '3', '6', '1', 'bebas', NULL, '2000000.00', '2000000.00', 'lunas', 'Tunai', '2025-05-20 12:11:07', '2025-06-10 06:21:28');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('238', '4', '6', '1', 'bebas', NULL, '2000000.00', '500000.00', 'belum', 'Tunai', '2025-05-20 12:11:07', '2025-06-10 06:49:53');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('239', '5', '6', '1', 'bebas', NULL, '2000000.00', '0.00', 'belum', NULL, '2025-05-20 12:11:07', '2025-05-20 12:11:07');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('240', '6', '6', '1', 'bebas', NULL, '2000000.00', '0.00', 'belum', NULL, '2025-05-20 12:11:07', '2025-05-20 12:11:07');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('241', '7', '6', '1', 'bebas', NULL, '2000000.00', '0.00', 'belum', NULL, '2025-05-20 12:11:07', '2025-05-20 12:11:07');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('242', '44', '6', '1', 'bebas', NULL, '2000000.00', '0.00', 'belum', NULL, '2025-05-20 12:11:07', '2025-05-20 12:11:07');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('243', '45', '6', '1', 'bebas', NULL, '2000000.00', '0.00', 'belum', NULL, '2025-05-20 12:11:07', '2025-05-20 12:11:07');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('244', '15', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('245', '15', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('246', '15', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('247', '15', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('248', '15', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('249', '15', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('250', '15', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('251', '15', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('252', '15', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('253', '15', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('254', '15', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('255', '15', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('256', '16', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('257', '16', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('258', '16', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('259', '16', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('260', '16', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('261', '16', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('262', '16', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('263', '16', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('264', '16', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('265', '16', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('266', '16', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('267', '16', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('268', '17', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('269', '17', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('270', '17', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('271', '17', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('272', '17', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('273', '17', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('274', '17', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('275', '17', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('276', '17', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('277', '17', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('278', '17', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('279', '17', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('280', '18', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('281', '18', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('282', '18', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('283', '18', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('284', '18', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('285', '18', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('286', '18', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('287', '18', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('288', '18', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('289', '18', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('290', '18', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('291', '18', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('292', '19', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('293', '19', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('294', '19', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('295', '19', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('296', '19', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('297', '19', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('298', '19', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('299', '19', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('300', '19', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('301', '19', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('302', '19', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('303', '19', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('304', '48', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('305', '48', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('306', '48', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('307', '48', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('308', '48', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('309', '48', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('310', '48', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('311', '48', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('312', '48', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('313', '48', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('314', '48', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('315', '48', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('316', '49', '1', '1', 'bulanan', '7', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('317', '49', '1', '1', 'bulanan', '8', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('318', '49', '1', '1', 'bulanan', '9', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('319', '49', '1', '1', 'bulanan', '10', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('320', '49', '1', '1', 'bulanan', '11', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('321', '49', '1', '1', 'bulanan', '12', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('322', '49', '1', '1', 'bulanan', '1', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('323', '49', '1', '1', 'bulanan', '2', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('324', '49', '1', '1', 'bulanan', '3', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('325', '49', '1', '1', 'bulanan', '4', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('326', '49', '1', '1', 'bulanan', '5', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('327', '49', '1', '1', 'bulanan', '6', '240000.00', '0.00', 'belum', NULL, '2025-06-06 15:37:20', '2025-06-06 15:37:20');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('328', '8', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('329', '9', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('330', '10', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('331', '11', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('332', '12', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('333', '13', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('334', '14', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('335', '46', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');
INSERT INTO `tagihan_siswa` (`id`, `siswa_id`, `jenis_bayar_id`, `tahun_ajaran_id`, `tipe`, `bulan`, `jumlah`, `terbayar`, `status`, `cara_bayar`, `created_at`, `updated_at`) VALUES ('336', '47', '6', '1', 'bebas', NULL, '1500000.00', '0.00', 'belum', NULL, '2025-06-07 11:14:35', '2025-06-07 11:14:47');

-- TABEL: tahun_ajaran
CREATE TABLE `tahun_ajaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(20) NOT NULL,
  `urutan` int(11) NOT NULL DEFAULT 0,
  `aktif` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tahun_ajaran` (`id`, `nama`, `urutan`, `aktif`, `created_at`, `updated_at`) VALUES ('1', '2024/2025', '1', '1', '2025-05-15 11:15:43', '2025-05-16 03:52:59');
INSERT INTO `tahun_ajaran` (`id`, `nama`, `urutan`, `aktif`, `created_at`, `updated_at`) VALUES ('2', '2025/2026', '2', '0', '2025-05-15 11:16:06', '2025-05-16 03:52:59');

-- TABEL: transaksi_pos
CREATE TABLE `transaksi_pos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos_bayar_id` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `tipe` enum('masuk','keluar') NOT NULL,
  `jumlah` int(11) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaksi_pos_pos_bayar_id_foreign` (`pos_bayar_id`),
  CONSTRAINT `transaksi_pos_pos_bayar_id_foreign` FOREIGN KEY (`pos_bayar_id`) REFERENCES `pos_bayar` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `transaksi_pos` (`id`, `pos_bayar_id`, `tanggal`, `tipe`, `jumlah`, `keterangan`, `created_at`, `updated_at`) VALUES ('1', '1', '2025-05-26', 'masuk', '1440000', 'Sinkronisasi otomatis dari pembayaran siswa', '2025-05-26 23:24:14', '2025-05-26 23:24:14');
INSERT INTO `transaksi_pos` (`id`, `pos_bayar_id`, `tanggal`, `tipe`, `jumlah`, `keterangan`, `created_at`, `updated_at`) VALUES ('4', '2', '2025-05-26', 'masuk', '1000000', 'Sinkronisasi otomatis dari pembayaran siswa', '2025-05-26 23:25:33', '2025-05-26 23:25:33');
INSERT INTO `transaksi_pos` (`id`, `pos_bayar_id`, `tanggal`, `tipe`, `jumlah`, `keterangan`, `created_at`, `updated_at`) VALUES ('6', '1', '2025-05-26', 'keluar', '250000', 'Bayar Honor', '2025-05-26 23:26:21', '2025-05-26 23:26:21');
INSERT INTO `transaksi_pos` (`id`, `pos_bayar_id`, `tanggal`, `tipe`, `jumlah`, `keterangan`, `created_at`, `updated_at`) VALUES ('7', '1', '2025-06-10', 'masuk', '4080000', 'Sinkronisasi otomatis dari pembayaran siswa', '2025-06-10 06:30:54', '2025-06-10 06:30:54');
INSERT INTO `transaksi_pos` (`id`, `pos_bayar_id`, `tanggal`, `tipe`, `jumlah`, `keterangan`, `created_at`, `updated_at`) VALUES ('10', '2', '2025-06-10', 'masuk', '6000000', 'Sinkronisasi otomatis dari pembayaran siswa', '2025-06-10 09:06:16', '2025-06-10 09:06:16');

-- TABEL: user_pos_bayar
CREATE TABLE `user_pos_bayar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `pos_bayar_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user_pos_bayar` (`id`, `user_id`, `pos_bayar_id`) VALUES ('1', '2', '3');
INSERT INTO `user_pos_bayar` (`id`, `user_id`, `pos_bayar_id`) VALUES ('2', '2', '2');

-- TABEL: users
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `role` enum('superadmin','admin','operator','staf') NOT NULL DEFAULT 'operator',
  `aktif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`id`, `username`, `password_hash`, `nama`, `role`, `aktif`, `created_at`, `updated_at`) VALUES ('1', 'superadmin', '$2y$10$Fjb63gg5YqLC3B/W7T/qNe/lJtamXMg2zoi4vAU39ilaGbC0AFLnG', 'Super Admin', 'superadmin', '1', '2025-05-15 06:34:02', '2025-06-10 11:43:16');
INSERT INTO `users` (`id`, `username`, `password_hash`, `nama`, `role`, `aktif`, `created_at`, `updated_at`) VALUES ('2', 'admin', '$2y$10$4I/9YhZKuGGM2SepQhinteAf1LC6Ez4GzV41qgFfwWKPr7nnS5dUC', 'Petugas admin SPP', 'admin', '1', '2025-05-15 06:34:03', '2025-06-10 11:43:28');
INSERT INTO `users` (`id`, `username`, `password_hash`, `nama`, `role`, `aktif`, `created_at`, `updated_at`) VALUES ('3', 'operator', '$2y$10$ix3Ls7GOxz26OHZGwqx5.O6ntX9La6UPKk/Arp2C2SkuN.ndnqOpm', 'Petugas Kegiatan', 'operator', '1', '2025-06-05 08:08:56', '2025-06-10 11:43:37');
INSERT INTO `users` (`id`, `username`, `password_hash`, `nama`, `role`, `aktif`, `created_at`, `updated_at`) VALUES ('4', 'staf', '$2y$10$hvh5da02314OhXhmMX8kOuQm14Xe/PnNjK0G3LoaA4t1urkVwLRDq', 'Petugas Pengawasan', 'staf', '1', '2025-06-05 08:09:18', '2025-06-10 11:43:48');

