<?php

namespace App\Controllers;

use App\Models\KelasSiswaModel;
use App\Models\TahunAjaranModel;
use App\Models\KelasModel;

class Kenaikan extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new KelasSiswaModel();
    }

    public function index()
    {
        $tahunAktif = (new TahunAjaranModel())->where('aktif', 1)->first();
        if (!$tahunAktif) {
            return redirect()->back()->with('msg', 'Tahun ajaran aktif belum diset.');
        }

        $tahunSebelumnya = (new TahunAjaranModel())
            ->where('id <', $tahunAktif['id'])
            ->orderBy('id', 'desc')
            ->first();

        if (!$tahunSebelumnya) {
            return redirect()->back()->with('msg', 'Belum ada tahun ajaran sebelumnya.');
        }

        $kelas = (new KelasModel())->where('aktif', 1)->findAll();

        $kelasFilter  = $this->request->getGet('kelas_id');
        $statusFilter = $this->request->getGet('status') ?? 'aktif';
        $siswa        = [];

        if ($kelasFilter) {
            // Siswa yang sudah punya entri di tahun aktif
            $sudahNaik = $this->model
                ->select('siswa_id')
                ->where('tahun_ajaran_id', $tahunAktif['id'])
                ->findColumn('siswa_id') ?? [];

            // Siswa yang sudah lulus di tahun sebelumnya
            $sudahLulus = $this->model
                ->select('siswa_id')
                ->where('tahun_ajaran_id', $tahunSebelumnya['id'])
                ->where('status', 'lulus')
                ->findColumn('siswa_id') ?? [];

            // Gabungkan untuk dikecualikan
            $excludeIds = array_unique(array_merge($sudahNaik, $sudahLulus));

            // 🔑 Ambil siswa di tahun sebelumnya, kelas terpilih, status filter
            $siswa = $this->model
                ->getByStatus($tahunSebelumnya['id'], $kelasFilter, $statusFilter);

            // 🔑 Kecualikan siswa yang sudah naik atau sudah lulus
            if ($excludeIds) {
                $siswa = array_filter($siswa, fn($s) => !in_array($s['siswa_id'], $excludeIds));
            }
        }

        return view('admin/kenaikan/index', [
            'title'          => 'Kenaikan/Kelulusan Siswa',
            'tahunSebelumnya'=> $tahunSebelumnya,
            'tahunSekarang'  => $tahunAktif,
            'kelas'          => $kelas,
            'kelasFilter'    => $kelasFilter,
            'statusFilter'   => $statusFilter,
            'siswa'          => $siswa,
        ]);
    }

    public function proses()
    {
        $siswaIds = $this->request->getPost('siswa_ids');
        $kelasTujuan = $this->request->getPost('kelas_id');
        $tahunId = $this->request->getPost('tahun_ajaran_id');
        $lulusIds = $this->request->getPost('lulus_ids') ?? [];

        if (!$siswaIds || !$tahunId) {
            return redirect()->back()->with('msg', 'Mohon pilih siswa.');
        }

        $data = [];
        $now = date('Y-m-d');
        $timestamp = date('Y-m-d H:i:s');

        foreach ($siswaIds as $id) {
            // Set entri lama jadi nonaktif
            $this->model->where('siswa_id', $id)->set(['status' => 'nonaktif'])->update();

            $data[] = [
                'siswa_id' => $id,
                'kelas_id' => in_array($id, $lulusIds) ? null : $kelasTujuan,
                'tahun_ajaran_id' => $tahunId,
                'status' => in_array($id, $lulusIds) ? 'lulus' : 'aktif',
                'tanggal_masuk' => $now,
                'created_at' => $timestamp,
                'updated_at' => $timestamp,
            ];
        }

        if ($data) $this->model->insertBatch($data);
        return redirect()->to('/admin/kenaikan')->with('msg', 'Proses berhasil.');
    }
}
