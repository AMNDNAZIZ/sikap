<?php

namespace App\Controllers;

use App\Models\KelasSiswaModel;
use App\Models\TahunAjaranModel;

class ArsipSiswa extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new KelasSiswaModel();
    }

    public function index()
    {
        $tahunAktif = (new TahunAjaranModel())->where('aktif', 1)->first();
        $status = $this->request->getGet('status') ?? 'lulus';
        $perPage = 20;
    
        // Jika BELUM ADA tahun ajaran aktif → skip query, tampilkan view kosong
        if (!$tahunAktif) {
            return view('admin/arsip_siswa/index', [
                'title'  => 'Arsip Siswa',
                'status' => $status,
                'siswa'  => [],
                'pager'  => null,
                'tahun'  => 'Belum diset'
            ]);
        }
    
        // Jika ADA → lanjutkan query
        $builder = $this->model->withRelations()
            ->where('kelas_siswa.tahun_ajaran_id', $tahunAktif['id'])
            ->where('kelas_siswa.status', $status);
    
        $siswa = $builder->paginate($perPage, 'default');
        $pager = $this->model->pager;
    
        return view('admin/arsip_siswa/index', [
            'title'  => 'Arsip Siswa',
            'status' => $status,
            'siswa'  => $siswa,
            'pager'  => $pager,
            'tahun'  => $tahunAktif['nama'] ?? '-'
        ]);
    }

    public function aktifkan($id)
    {
        $row = $this->model->find($id);
        if (!$row) {
            return redirect()->back()->with('msg', 'Data tidak ditemukan.');
        }

        $this->model->update($id, [
            'status' => 'aktif',
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->back()->with('msg', 'Status siswa berhasil diaktifkan kembali.');
    }

}
