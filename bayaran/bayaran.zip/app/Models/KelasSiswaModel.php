<?php

namespace App\Models;

use CodeIgniter\Model;

class KelasSiswaModel extends Model
{
    protected $table = 'kelas_siswa';
    protected $allowedFields = [
        'siswa_id', 
        'kelas_id', 
        'tahun_ajaran_id', 
        'status', 
        'tanggal_masuk', 
        'tanggal_keluar'
    ];
    protected $useTimestamps = true;

    public function withRelations()
    {
        return $this->select('kelas_siswa.*, siswa.nis, siswa.nama, kelas.nama_kelas, tahun_ajaran.nama as tahun')
            ->join('siswa', 'siswa.id = kelas_siswa.siswa_id')
            ->join('kelas', 'kelas.id = kelas_siswa.kelas_id', 'left') // pakai LEFT JOIN biar aman kalau kelas null
            ->join('tahun_ajaran', 'tahun_ajaran.id = kelas_siswa.tahun_ajaran_id');
    }

    // ✅ Tambahan modern: filter by status
    public function getByStatus($tahunId, $kelasId = null, $status = null)
    {
        $builder = $this->withRelations()->where('kelas_siswa.tahun_ajaran_id', $tahunId);
        if ($kelasId) $builder->where('kelas_siswa.kelas_id', $kelasId);
        if ($status)  $builder->where('kelas_siswa.status', $status);
        return $builder->findAll();
    }
}
