<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h4>Kenaikan / Kelulusan Siswa</h4>

<?php if (session()->getFlashdata('msg')): ?>
  <div class="alert alert-info"><?= session()->getFlashdata('msg') ?></div>
<?php endif; ?>

<form method="get" class="row mb-3">
  <div class="col-md-4">
    <label>Filter Kelas Tahun <?= esc($tahunSebelumnya['nama']) ?></label>
    <select name="kelas_id" class="form-select" required onchange="this.form.submit()">
      <option value="">-- Pilih Kelas --</option>
      <?php foreach ($kelas as $k): ?>
        <option value="<?= $k['id'] ?>" <?= $kelasFilter == $k['id'] ? 'selected' : '' ?>>
          <?= esc($k['nama_kelas']) ?>
        </option>
      <?php endforeach ?>
    </select>
  </div>
</form>

<?php if ($siswa): ?>
<form method="post" action="<?= site_url('admin/kenaikan/proses') ?>">
  <input type="hidden" name="tahun_ajaran_id" value="<?= $tahunSekarang['id'] ?>">

  <div class="row mb-3">
    <div class="col-md-4">
      <label>Naik ke Kelas Tujuan</label>
      <select name="kelas_id" class="form-select">
        <option value="">-- Tidak naik --</option>
        <?php foreach ($kelas as $k): ?>
          <option value="<?= $k['id'] ?>"><?= esc($k['nama_kelas']) ?></option>
        <?php endforeach ?>
      </select>
    </div>
  </div>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th><input type="checkbox" id="check-all"> Pilih Semua</th>
        <th>NIS</th>
        <th>Nama</th>
        <th>
          Centang Jika Lulus<br>
          <input type="checkbox" id="check-all-lulus">
        </th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($siswa as $s): ?>
        <tr>
          <td><input type="checkbox" name="siswa_ids[]" value="<?= $s['siswa_id'] ?>"></td>
          <td><?= esc($s['nis']) ?></td>
          <td><?= esc($s['nama']) ?></td>
          <td><input type="checkbox" name="lulus_ids[]" value="<?= $s['siswa_id'] ?>"></td>
        </tr>
      <?php endforeach ?>
    </tbody>
  </table>

  <button class="btn btn-primary">Proses Kenaikan / Kelulusan</button>
</form>

<script>
document.getElementById('check-all').addEventListener('click', function() {
  document.querySelectorAll('input[name="siswa_ids[]"]').forEach(cb => cb.checked = this.checked);
});
document.getElementById('check-all-lulus').addEventListener('click', function() {
  document.querySelectorAll('input[name="lulus_ids[]"]').forEach(cb => cb.checked = this.checked);
});
</script>

<?php elseif ($kelasFilter): ?>
<div class="alert alert-warning">Tidak ada siswa di kelas ini.</div>
<?php endif ?>

<?= $this->endSection() ?>
