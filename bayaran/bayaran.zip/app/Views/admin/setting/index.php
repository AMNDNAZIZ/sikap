<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h4>Setting Sekolah</h4>

<?php if (session()->getFlashdata('msg')): ?>
  <div class="alert alert-success"><?= esc(session()->getFlashdata('msg')) ?></div>
<?php endif ?>

<form method="post" action="<?= site_url('admin/setting/save') ?>" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <div class="mb-3">
    <label>Nama Aplikasi</label>
    <input type="text" name="nama_aplikasi" value="<?= esc($setting['nama_aplikasi'] ?? '') ?>" class="form-control"
      required>
  </div>
  <div class="mb-3">
    <label>Nama Sekolah</label>
    <input type="text" name="nama_sekolah" value="<?= esc($setting['nama_sekolah'] ?? '') ?>" class="form-control"
      required>
  </div>
  <div class="mb-3">
    <label>Alamat</label>
    <textarea name="alamat" class="form-control" required><?= esc($setting['alamat'] ?? '') ?></textarea>
  </div>
  <div class="mb-3">
    <label>No. HP</label>
    <input type="text" name="no_hp" value="<?= esc($setting['no_hp'] ?? '') ?>" class="form-control">
  </div>
  <div class="mb-3">
    <label>Nama Kepala Sekolah</label>
    <input type="text" name="kepala_sekolah" value="<?= esc($setting['kepala_sekolah'] ?? '') ?>" class="form-control">
  </div>
  <div class="mb-3">
    <label>Website</label>
    <input type="text" name="website" value="<?= esc($setting['website'] ?? '') ?>" class="form-control">
  </div>
  <div class="mb-3">
    <label>Email</label>
    <input type="email" name="email" value="<?= esc($setting['email'] ?? '') ?>" class="form-control">
  </div>
  <div class="mb-3">
    <label>Logo Sekolah</label><br>
    <?php if (!empty($setting['logo'])): ?>
      <img src="<?= base_url($setting['logo']) ?>" alt="Logo" height="100" class="mb-2 d-block">
    <?php endif ?>
    <input type="file" name="logo" class="form-control">
  </div>
  <button class="btn btn-primary">Simpan</button>
</form>

<?= $this->endSection() ?>