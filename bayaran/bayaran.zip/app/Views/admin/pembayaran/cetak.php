<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>BUKTI BAYAR <?= esc($data['nama_jenis_bayar']) ?> <?= esc($data['nama_siswa']) ?></title>
  <link href="<?= base_url('public/assets/css/bootstrap.min.css') ?>" rel="stylesheet">
  <style>
    body {
      font-size: 13px;
      font-family: Arial, sans-serif;
      margin: 2rem;
      line-height: 1;
    }

    .kop {
      text-align: center;
      margin-bottom: 1rem;
    }

    .kop img {
      height: 60px;
      margin-bottom: 0.5rem;
    }

    .kop h6 {
      margin-bottom: 0;
      font-size: 1.5rem;
      font-weight: bold;
    }

    .kop p {
      margin: 0;
      font-size: 0.9rem;
      line-height: 1;
    }

    .judul {
      text-align: center;
      font-weight: bold;
      margin-top: 0.5rem;
      margin-bottom: 1rem;
    }

    table th,
    table td {
      padding: 0.5px 1px;
      line-height: 0.5;
      font-size: 12px;
    }

    table th {
      width: 100px;
      vertical-align: top;
    }

    .qr {
      margin-top: 1.5rem;
    }

    .garis {
      border-top: 1px dashed #000;
      margin-top: 0.5rem;
      margin-bottom: 0.5rem;
    }
  </style>
</head>

<body onload="window.print()">

  <!-- 🏫 KOP SEKOLAH -->
  <div class="kop">
    <?php if (!empty($setting['logo'])): ?>
      <img src="<?= base_url($setting['logo']) ?>" alt="Logo">
    <?php endif ?>
    <h5><?= strtoupper($setting['nama_sekolah'] ?? 'NAMA SEKOLAH') ?></h5>
    <p><?= $setting['alamat'] ?? 'Alamat belum diatur' ?></p>
    <p>WA: <?= $setting['no_hp'] ?? '-' ?></p>
  </div>

  <div class="garis"></div>

  <!-- 🧾 Judul -->
  <div class="judul">
    BUKTI PEMBAYARAN <br>
    <?= esc($data['nama_jenis_bayar']) ?>
  </div>
  <div class="garis"></div>

  <!-- 📄 Tabel Data -->
  <table class="table table-borderless w-auto">
    <tr>
      <th colspan="2"><?= esc($data['nama_siswa']) ?></th>
    </tr>
    <tr>
      <th>NIS</th>
      <td>: <?= esc($data['nis']) ?></td>
    </tr>
    <tr>
      <th>Kelas</th>
      <td>: <?= esc($data['nama_kelas'] ?? '-') ?></td>
    </tr>

    <?php if ($data['tipe'] === 'bulanan'): ?>
      <tr>
        <th>Bayar Bulan</th>
        <td>: <?= bulanIndo($data['bulan']) ?></td>
      </tr>
    <?php endif ?>

    <tr>
      <th>Tgl. Bayar</th>
      <td>: <?= date('d-m-Y', strtotime($data['tanggal'])) ?></td>
    </tr>
    <tr>
      <th>Cara Bayar</th>
      <td>: <?= ucfirst($data['cara_bayar']) ?></td>
    </tr>
    <tr>
      <th>Jumlah </th>
      <td>: Rp <?= number_format($data['jumlah_bayar'], 0, ',', '.') ?></td>
    </tr>

    <?php if ($data['tipe'] === 'bebas'): ?>
      <tr>
        <th>Keterangan</th>
        <td>: <?= esc($data['keterangan'] ?: '-') ?></td>
      </tr>
      <tr>
        <th>Sisa</th>
        <td>: Rp <?= number_format(max(0, $data['total_tagihan'] - $data['terbayar']), 0, ',', '.') ?></td>
      </tr>
    <?php endif ?>

    <tr>
      <th>Status</th>
      <td>: <?= $data['status_tagihan'] === 'lunas' ? 'Lunas' : 'Belum Lunas' ?></td>
    </tr>
  </table>
  <p class="mt-3"><small>Rincian pembayaran bisa dilihat di https://bayaran.smpistora.sch.id</small></p>
  <!-- 🔲 QR Code -->
  <?php if (!empty($qrCode)): ?>
    <div class="qr text-center">
      <img src="data:image/svg+xml;base64,<?= $qrCode ?>" alt="QR Code">
    </div>
  <?php endif ?>

  <!-- 🌐 Footer -->


</body>

</html>