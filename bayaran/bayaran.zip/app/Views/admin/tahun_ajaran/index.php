<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h4>Manajemen Tahun Ajaran</h4>

<?php if(session()->getFlashdata('msg')): ?>
  <div class="alert alert-success"><?= session()->getFlashdata('msg') ?></div>
<?php endif; ?>

<?php $edit = $edit ?? null; ?>

<form action="<?= site_url('admin/tahun-ajaran/save') ?>" method="post" class="row g-2 mb-4">
  <input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">
  
  <div class="col-md-3">
    <input type="text" name="nama" class="form-control" placeholder="Contoh: 2024/2025"
           value="<?= $edit['nama'] ?? '' ?>" required>
  </div>
  <div class="col-md-2">
    <input type="date" name="mulai" class="form-control"
           value="<?= $edit['mulai'] ?? '' ?>" required>
  </div>
  <div class="col-md-2">
    <input type="date" name="selesai" class="form-control"
           value="<?= $edit['selesai'] ?? '' ?>" required>
  </div>
  <div class="col-md-2">
    <input type="number" name="urutan" class="form-control" placeholder="Urutan"
           value="<?= $edit['urutan'] ?? '' ?>" required>
  </div>
  <div class="col-md-2">
    <button class="btn btn-primary w-100"><?= $edit ? 'Update' : 'Tambah' ?></button>
    <?php if ($edit): ?>
      <a href="<?= site_url('admin/tahun-ajaran') ?>" class="btn btn-secondary w-100 mt-2">Batal</a>
    <?php endif ?>
  </div>
</form>

<table class="table table-bordered">
  <thead>
    <tr>
      <th>#</th>
      <th>Nama</th>
      <th>Mulai</th>
      <th>Selesai</th>
      <th>Urutan</th>
      <th>Status</th>
      <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
      <?php $no = 1; ?>
    <?php foreach ($list as $item): ?>
      <tr>
        <td><?= $no++; ?></td>
        <td><?= esc($item['nama']) ?></td>
        <td><?= esc($item['mulai']) ?></td>
        <td><?= esc($item['selesai']) ?></td>
        <td><?= esc($item['urutan']) ?></td>
        <td>
          <?php if ($item['aktif']): ?>
            <span class="badge bg-success">Aktif</span>
          <?php else: ?>
            <a href="<?= site_url('admin/tahun-ajaran/set-aktif/'.$item['id']) ?>" class="btn btn-sm btn-outline-primary">Set Aktif</a>
          <?php endif ?>
        </td>
        <td>
          <a href="<?= site_url('admin/tahun-ajaran/edit/'.$item['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
          <a href="<?= site_url('admin/tahun-ajaran/delete/'.$item['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</a>
        </td>
      </tr>
    <?php endforeach ?>
  </tbody>
</table>

<?= $this->endSection() ?>
