<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title><?= esc($title ?? 'Dashboard Admin') ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="<?= base_url('public/favicon.ico') ?>" type="image/ico">
  <link rel="manifest" href="<?= base_url('manifest.json') ?>">
  <meta name="theme-color" content="#667eea">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@600;700&display=swap"
    rel="stylesheet">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root {
      --sidebar-width: 260px;
      --sidebar-slim-width: 80px;

      --primary: #667eea;
      --secondary: #764ba2;
      --accent: #667eea;

      --sidebar-bg: #ffffff;
      --sidebar-text: #4b4b4b;
      --sidebar-hover: #f8f9fa;
      --sidebar-active-bg: rgba(102, 126, 234, 0.1);
      --sidebar-active-text: #667eea;

      --content-bg: #f5f7fb;
      --card-bg: #ffffff;
      --nav-bg: rgba(255, 255, 255, 0.8);

      --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.02);
      --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.05);
      --border-radius: 12px;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: var(--content-bg);
      color: #2d3436;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      padding-top: 70px;
    }

    .navbar {
      height: 70px;
      background: var(--nav-bg) !important;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(0, 0, 0, 0.05);
      z-index: 1030;
    }

    .navbar-brand {
      font-family: 'Outfit', sans-serif;
      font-weight: 700;
      color: var(--secondary) !important;
      font-size: 1.25rem;
    }

    .sidebar {
      width: var(--sidebar-width);
      background: var(--sidebar-bg);
      padding: 1.25rem;
      border-right: 1px solid rgba(0, 0, 0, 0.05);
      box-shadow: 4px 0 15px rgba(0, 0, 0, 0.02);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      height: calc(100vh - 70px);
      position: sticky;
      top: 70px;
      overflow-y: auto;
    }

    .sidebar::-webkit-scrollbar {
      width: 5px;
    }

    .sidebar::-webkit-scrollbar-thumb {
      background: #eee;
      border-radius: 10px;
    }

    .sidebar a {
      color: var(--sidebar-text);
      padding: 0.75rem 1rem;
      border-radius: var(--border-radius);
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 0.9rem;
      font-weight: 500;
      text-decoration: none;
      transition: all 0.2s ease;
      margin-bottom: 4px;
    }

    .sidebar a:hover {
      background: var(--sidebar-hover);
      color: var(--primary);
      transform: translateX(4px);
    }

    .sidebar a.active {
      background: var(--sidebar-active-bg);
      color: var(--sidebar-active-text);
      font-weight: 600;
    }

    .nav-icon {
      font-size: 1.1rem;
      width: 20px;
      text-align: center;
    }

    .sidebar.slim {
      width: var(--sidebar-slim-width);
      padding: 1.25rem 0.75rem;
    }

    .sidebar.slim .nav-link {
      justify-content: center;
      padding: 0.75rem 0;
    }

    .sidebar.slim .nav-link span {
      display: none;
    }

    .sidebar.slim .collapse,
    .sidebar.slim .dropdown-toggle::after {
      display: none !important;
    }

    main {
      flex-grow: 1;
      padding: 2rem;
      background: var(--content-bg);
    }

    .card {
      border: none;
      border-radius: var(--border-radius);
      box-shadow: var(--shadow-sm);
      transition: box-shadow 0.3s ease;
    }

    .card:hover {
      box-shadow: var(--shadow-md);
    }

    footer {
      background: #ffffff;
      text-align: center;
      padding: 1.5rem;
      font-size: 0.85rem;
      border-top: 1px solid rgba(0, 0, 0, 0.05);
      color: #636e72;
    }

    .btn-outline-secondary {
      border-color: #dfe6e9;
      color: #636e72;
    }

    .btn-outline-secondary:hover {
      background: #f8f9fa;
      color: var(--primary);
      border-color: var(--primary);
    }

    @media (max-width: 767.98px) {
      .sidebar {
        width: 280px !important;
        position: fixed;
        left: 0;
        top: 0;
        height: 100vh;
        z-index: 1040;
      }

      main {
        padding: 1.5rem 1rem;
      }
    }

    @media (min-width: 768px) {
      .offcanvas-md {
        position: sticky !important;
        transform: none !important;
        visibility: visible !important;
        display: block !important;
        height: calc(100vh - 70px) !important;
        top: 70px;
      }

      .offcanvas-md .offcanvas-header {
        display: none !important;
      }
    }
  </style>
</head>

<body class="d-flex flex-column min-vh-100">

  <!-- Navbar -->
  <nav class="navbar navbar-light shadow-sm fixed-top">
    <div class="container-fluid px-4">
      <div class="d-flex align-items-center">
        <button class="btn btn-outline-secondary d-md-none me-3" type="button" data-bs-toggle="offcanvas"
          data-bs-target="#sidebarMenu">
          <i class="bi bi-list"></i>
        </button>
        <button class="btn btn-outline-secondary d-none d-md-block" id="toggleSidebar">
          <i class="bi bi-text-indent-left"></i>
        </button>
        <span class="navbar-brand ms-3"><?= esc($title ?? 'Admin Panel') ?></span>
      </div>
      <div class="d-flex align-items-center gap-3">
        <div class="dropdown">
          <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" data-bs-toggle="dropdown"
            aria-expanded="false">
            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2"
              style="width: 35px; height: 35px; font-weight: 600;">
              <?= substr(session()->get('username') ?? 'A', 0, 1) ?>
            </div>
            <div class="d-none d-sm-block text-dark">
              <div style="font-size: 0.85rem; font-weight: 600; line-height: 1;"><?= esc(session()->get('username')) ?>
              </div>
              <small class="text-muted" style="font-size: 0.7rem;"><?= esc(ucfirst(session()->get('role'))) ?></small>
            </div>
          </a>
          <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2" style="border-radius: 12px;">
            <li><a class="dropdown-item py-2" href="<?= site_url('admin/profile') ?>"><i class="bi bi-person me-2"></i>
                Profil Saya</a></li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <li><a class="dropdown-item py-2 text-danger" href="<?= site_url('logout') ?>"><i
                  class="bi bi-box-arrow-right me-2"></i> Keluar</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>

  <!-- Layout -->
  <div class="d-flex flex-grow-1">
    <!-- Sidebar -->
    <div class="offcanvas offcanvas-start sidebar offcanvas-md" tabindex="-1" id="sidebarMenu">
      <div class="offcanvas-header d-md-none border-bottom px-4">
        <h5 class="offcanvas-title font-outfit" style="font-weight: 700; color: var(--secondary);">MENU</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
      </div>
      <div class="offcanvas-body px-3 py-4">
        <ul class="nav flex-column">
          <?php
          $role = session()->get('role') ?? 'guest';

          function canAccess($item, $role)
          {
            return !isset($item['allowed_roles']) || in_array($role, $item['allowed_roles']) || $role === 'superadmin';
          }

          $menus = [
            ['icon' => 'bi-grid-1x2', 'text' => 'Dashboard', 'url' => 'admin/dashboard'],

            [
              'icon' => 'bi-layers',
              'text' => 'Data Master',
              'id' => 'masterMenu',
              'children' => [
                ['text' => '🏫 Sekolah', 'url' => 'admin/setting'],
                ['text' => '📅 Tahun Ajaran', 'url' => 'admin/tahun-ajaran'],
                ['text' => '🏫 Kelas', 'url' => 'admin/kelas'],
                ['text' => '👨‍🎓 Siswa', 'url' => 'admin/siswa'],
                ['text' => '➕ Penempatan', 'url' => 'admin/penempatan'],
                ['text' => '📘 Kelas Aktif', 'url' => 'admin/kelas-aktif'],
                ['text' => '⬆️ Kenaikan/Lulus', 'url' => 'admin/kenaikan'],
                ['text' => '📁 Arsip Siswa', 'url' => 'admin/arsip-siswa'],
              ],
              'allowed_roles' => ['admin']
            ],

            [
              'icon' => 'bi-gear',
              'text' => 'Keuangan',
              'id' => 'keuanganMenu',
              'children' => [
                ['text' => '💳 Pos Bayar', 'url' => 'admin/pos-bayar'],
                ['text' => '💰 Jenis Bayar', 'url' => 'admin/jenis-bayar'],
              ],
              'allowed_roles' => ['admin']
            ],

            ['icon' => 'bi-wallet2', 'text' => 'Pembayaran', 'url' => 'admin/pembayaran', 'allowed_roles' => ['admin', 'operator']],
            ['icon' => 'bi-journal-check', 'text' => 'Utang Piutang', 'url' => 'admin/kasbon', 'allowed_roles' => ['admin', 'operator', 'staf']],
            ['icon' => 'bi-broadcast-pin', 'text' => 'Pengumuman', 'url' => 'admin/pengumuman', 'allowed_roles' => ['admin']],
            ['icon' => 'bi-arrow-left-right', 'text' => 'Arus Kas', 'url' => 'admin/transaksi-pos', 'allowed_roles' => ['admin', 'operator', 'staf']],

            [
              'icon' => 'bi-graph-up-arrow',
              'text' => 'Pelaporan',
              'id' => 'laporanMenu',
              'allowed_roles' => ['admin', 'operator', 'staf'],
              'children' => [
                ['text' => '📆 Harian', 'url' => 'admin/laporan/harian'],
                ['text' => '🗓️ Periode', 'url' => 'admin/laporan/periode'],
                ['text' => '📄 Tagihan Siswa', 'url' => 'admin/laporan/tagihan'],
                ['text' => '📄 Tagihan Filter', 'url' => 'admin/laporan/filter-tagihan'],
                ['text' => '🗓️ Per Tahun', 'url' => 'admin/laporanlain/per-tahun'],
                ['text' => '📅 Per Bulan', 'url' => 'admin/laporanlain/per-bulan'],
                ['text' => '📊 Rentang', 'url' => 'admin/laporanlain/rentang'],
              ]
            ],

            ['icon' => 'bi-people', 'text' => 'User Manajemen', 'url' => 'admin/user', 'allowed_roles' => ['admin']],
            ['icon' => 'bi-shield-check', 'text' => 'Database', 'url' => 'admin/backup-restore', 'allowed_roles' => ['admin']],
          ];

          foreach ($menus as $menu):
            if (!canAccess($menu, $role))
              continue;

            $menuUrl = $menu['url'] ?? null;
            $hasChildren = isset($menu['children']);
            $isActive = (($menuUrl && uri_string() === $menuUrl) || ($hasChildren && array_search(uri_string(), array_column($menu['children'], 'url')) !== false));

            if ($hasChildren): ?>
              <li class="nav-item">
                <a class="nav-link dropdown-toggle <?= $isActive ? 'active' : '' ?>" data-bs-toggle="collapse"
                  href="#<?= $menu['id'] ?>" role="button" aria-expanded="<?= $isActive ? 'true' : 'false' ?>">
                  <i class="bi <?= $menu['icon'] ?> nav-icon"></i> <span><?= $menu['text'] ?></span>
                </a>
                <div class="collapse <?= $isActive ? 'show' : '' ?> ms-3" id="<?= $menu['id'] ?>">
                  <?php foreach ($menu['children'] as $child): ?>
                    <a class="nav-link py-1 mb-1 <?= uri_string() === $child['url'] ? 'active' : '' ?>"
                      href="<?= site_url($child['url']) ?>"
                      style="font-size: 0.85rem; border-left: 2px solid transparent; border-radius: 0 8px 8px 0;">
                      <span><?= $child['text'] ?></span>
                    </a>
                  <?php endforeach; ?>
                </div>
              </li>
            <?php else: ?>
              <li class="nav-item">
                <a class="nav-link <?= $menuUrl && uri_string() === $menuUrl ? 'active' : '' ?>"
                  href="<?= site_url($menuUrl ?? '#') ?>">
                  <i class="bi <?= $menu['icon'] ?> nav-icon"></i> <span><?= $menu['text'] ?></span>
                </a>
              </li>
            <?php endif;
          endforeach;
          ?>

          <li class="nav-item mt-4 pt-3 border-top">
            <a class="nav-link text-danger" href="<?= site_url('logout') ?>">
              <i class="bi bi-power nav-icon"></i> <span>Keluar</span>
            </a>
          </li>
        </ul>
      </div>
    </div>

    <!-- Main Content -->
    <main class="w-100 overflow-hidden">
      <div class="container-fluid">
        <?= $this->renderSection('content') ?>
      </div>
    </main>
  </div>


  <!-- Footer -->
  <footer class="mt-auto">
    <div class="container-fluid px-4">
      <div class="d-flex justify-content-between align-items-center">
        <small>&copy; <?= date('Y') ?> <strong>SakaSalika™</strong> – Modern Payment System</small>
        <small class="text-muted">v2.0-Alpha</small>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    const sidebar = document.querySelector('.sidebar');
    const toggleSidebarBtn = document.getElementById('toggleSidebar');
    const toggleIcon = toggleSidebarBtn ? toggleSidebarBtn.querySelector('i') : null;

    if (toggleSidebarBtn && sidebar) {
      toggleSidebarBtn.addEventListener('click', () => {
        sidebar.classList.toggle('slim');
        const isSlim = sidebar.classList.contains('slim');
        localStorage.setItem('sidebarSlim', isSlim);

        if (toggleIcon) {
          toggleIcon.className = isSlim ? 'bi bi-text-indent-right' : 'bi bi-text-indent-left';
        }
      });

      if (window.innerWidth >= 768 && localStorage.getItem('sidebarSlim') === 'true') {
        sidebar.classList.add('slim');
        if (toggleIcon) toggleIcon.className = 'bi bi-text-indent-right';
      }
    }

    document.querySelectorAll('#sidebarMenu a.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        const hasSub = link.classList.contains('dropdown-toggle');
        if (!hasSub && window.innerWidth < 768) {
          const sidebarInstance = bootstrap.Offcanvas.getInstance(document.getElementById('sidebarMenu'));
          if (sidebarInstance) sidebarInstance.hide();
        }
      });
    });

    // PWA Service Worker Registration
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('<?= base_url('service-worker.js') ?>')
          .then(reg => console.log('Service Worker registered', reg))
          .catch(err => console.log('Service Worker registration failed', err));
      });
    }
  </script>
</body>

</html>