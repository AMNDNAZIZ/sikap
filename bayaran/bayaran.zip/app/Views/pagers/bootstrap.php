<?php if ($pager->getPageCount() > 1): ?>

    <nav>
        <ul class="pagination">
            <?php if ($pager->hasPrevious()): ?>
                <li class="page-item">
                    <a href="<?= $pager->getPreviousPage() ?>" class="page-link" aria-label="Previous">
                        &laquo;
                    </a>
                </li>
            <?php endif ?>

            <?php foreach ($pager->links() as $link): ?>
                <li class="page-item <?= $link['active'] ? 'active' : '' ?>">
                    <a href="<?= $link['uri'] ?>" class="page-link">
                        <?= $link['title'] ?>
                    </a>
                </li>
            <?php endforeach ?>

            <?php if ($pager->hasNext()): ?>
                <li class="page-item">
                    <a href="<?= $pager->getNextPage() ?>" class="page-link" aria-label="Next">
                        &raquo;
                    </a>
                </li>
            <?php endif ?>
        </ul>
    </nav>
<?php endif ?>
