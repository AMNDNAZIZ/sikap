-- ============================================================
-- Fix Image URLs in cbt_questions
-- Ganti URL localhost/lokal ke URL production
-- JUGA ganti http:// → https:// (fix mixed content di HP)
--
-- SESUAIKAN: ganti 'https://cbtsmpistora.sch.id' dengan URL server Anda
-- Jalankan: mysql -u root -p cbtistora < scripts/fix_image_urls.sql
-- ============================================================

SET @production_url = 'https://cbtsmpistora.sch.id';
SET @production_host = 'cbtsmpistora.sch.id';

-- ─── Fix question_text ────────────────────────────────────────

-- Ganti http://localhost → production
UPDATE cbt_questions 
SET question_text = REPLACE(question_text, 'http://localhost/uploads/', CONCAT(@production_url, '/uploads/'))
WHERE question_text LIKE '%http://localhost/uploads/%';

UPDATE cbt_questions 
SET question_text = REPLACE(question_text, 'http://localhost:8080/uploads/', CONCAT(@production_url, '/uploads/'))
WHERE question_text LIKE '%http://localhost:8080/uploads/%';

UPDATE cbt_questions 
SET question_text = REPLACE(question_text, 'http://127.0.0.1/uploads/', CONCAT(@production_url, '/uploads/'))
WHERE question_text LIKE '%http://127.0.0.1/uploads/%';

-- Ganti /public/uploads/ → /uploads/
UPDATE cbt_questions 
SET question_text = REPLACE(question_text, '/public/uploads/', '/uploads/')
WHERE question_text LIKE '%/public/uploads/%';

-- FIX MIXED CONTENT: Ganti http://domain → https://domain
UPDATE cbt_questions 
SET question_text = REPLACE(question_text, CONCAT('http://', @production_host, '/'), CONCAT('https://', @production_host, '/'))
WHERE question_text LIKE CONCAT('%http://', @production_host, '/%');

-- ─── Fix raw_text ─────────────────────────────────────────────

UPDATE cbt_questions 
SET raw_text = REPLACE(raw_text, 'http://localhost/uploads/', CONCAT(@production_url, '/uploads/'))
WHERE raw_text LIKE '%http://localhost/uploads/%';

UPDATE cbt_questions 
SET raw_text = REPLACE(raw_text, 'http://localhost:8080/uploads/', CONCAT(@production_url, '/uploads/'))
WHERE raw_text LIKE '%http://localhost:8080/uploads/%';

UPDATE cbt_questions 
SET raw_text = REPLACE(raw_text, 'http://127.0.0.1/uploads/', CONCAT(@production_url, '/uploads/'))
WHERE raw_text LIKE '%http://127.0.0.1/uploads/%';

UPDATE cbt_questions 
SET raw_text = REPLACE(raw_text, '/public/uploads/', '/uploads/')
WHERE raw_text LIKE '%/public/uploads/%';

-- FIX MIXED CONTENT: Ganti http://domain → https://domain
UPDATE cbt_questions 
SET raw_text = REPLACE(raw_text, CONCAT('http://', @production_host, '/'), CONCAT('https://', @production_host, '/'))
WHERE raw_text LIKE CONCAT('%http://', @production_host, '/%');

-- ─── Verifikasi: cek apakah masih ada http:// ─────────────────

SELECT 'question_text dengan http://' AS check_type, COUNT(*) AS jumlah
FROM cbt_questions 
WHERE question_text LIKE CONCAT('%http://', @production_host, '%');

SELECT 'raw_text dengan http://' AS check_type, COUNT(*) AS jumlah
FROM cbt_questions 
WHERE raw_text LIKE CONCAT('%http://', @production_host, '%');

SELECT 'Soal dengan gambar (total)' AS check_type, COUNT(*) AS jumlah
FROM cbt_questions 
WHERE question_text LIKE '%<img%' OR raw_text LIKE '%<img%';
