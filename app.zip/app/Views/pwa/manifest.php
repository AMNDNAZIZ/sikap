{
"name": "SIKAP - Sistem Informasi Kelas Absensi dan Penilaian",
"short_name": "SIKAP",
"description": "Sistem Informasi Kelas Absensi dan Penilaian",
"start_url": "./",
"scope": "./",
"display": "standalone",
"background_color": "#ffffff",
"theme_color": "#0d6efd",
"orientation": "any",
"icons": [
{
"src": "assets/images/logo-192.png",
"sizes": "192x192",
"type": "image/png",
"purpose": "any maskable"
},
{
"src": "assets/images/logo-512.png",
"sizes": "512x512",
"type": "image/png",
"purpose": "any maskable"
}
]
}